import { Injectable } from '@angular/core';

@Injectable()
export class SubscribeService{

    OnSubscribeClicked(type: string){
        //ADD USER TO DATABASE
    
        //SEND EMAIL WITH SUBSCRIPTION DETAIL
    
        //ALLOW USER TO ACCESS THE SERVICES
    
        alert('Thank you for your '+type+' subscription. You can access the services now.');
    }
}